<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet"/>
<title>Data Produk </title>
</head>
<body>
<?php
include('class/Database.php');
include('class/Produk.php');
include('class/macam_produk.php');
?>
<h1>Aplikasi Data Produk Makanan</h1>
<hr/>
<p>
<a href="index.php">Home</a>

<a href="index.php?file=produk&aksi=tampil">Data Produk</a>

<a href="index.php?file=macam_produk&aksi=tampil">Macam-Macam Produk</a>

<button onclick="printFunction()">Print</button>
</p>
<hr/>


<script>
  function printFunction() { 
    window.print(); 
  }
</script>
<?php
if(isset($_GET['file'])){
include($_GET['file'].'.php');
} else {
echo '<h1 align="center">Selamat Datang</h1>';
}
?>
</body>
</html>