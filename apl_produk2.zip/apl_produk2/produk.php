<?php
// membuat instance
$dataProduk=NEW Produk;
// aksi tampil data
if($_GET['aksi']=='tampil'){
// aksi untuk tampil data
$html = null;
$html .='<h3>Daftar Produk</h3>';
$html .='<p>Berikut ini data Produk </p>';
$html .='<table border="1" width="100%" class="table table-striped table-hover">
<a href="index.php?file=Produk&aksi=tambah">Tambah Data Produk </a>
<thead>
<th>No</th>
<th>ID Produk</th>
<th>Nama Produk</th>
<th>Deskripsi</th>
<th>Harga Beli</th>
<th>Harga jual</th>

<th>Aksi</th>
</thead>
<tbody>';
// variabel $data menyimpan hasil return
$data = $dataProduk->tampil();
$no=null;
if(isset($data)){
foreach($data as $barisProduk)

{
$no++;
$html .='<tr>
<td>'.$no.'</td>
<td>'.$barisProduk->id.'</td>
<td>'.$barisProduk->nama_produk.'</td>
<td>'.$barisProduk->deskripsi.'</td>
<td>'.$barisProduk->harga_beli.'</td>
<td>'.$barisProduk->harga_jual.'</td>
<td>
<a
href="index.php?file=Produk&aksi=edit&id='.$barisProduk->id.'">Edit</a>
<a
href="index.php?file=Produk&aksi=hapus&id='.$barisProduk->id.'">Hapus</a>
</td>
</tr>';
}
}
$html .='</tbody>
</table>';
echo $html;
}
// aksi tambah data
else if ($_GET['aksi']=='tambah') {
$html =null;
$html .='<h3>Form Tambah</h3>';

$html .='<p>Silahkan masukan form </p>';

$html .='<form method="POST"
action="index.php?file=Produk&aksi=simpan">';

$html .='<p>masukan ID Produk<br/>';

$html .='<input type="text" name="txtid"
placeholder="Masukan ID Produk" autofocus/></p>';

$html .='<p>NamaProduk<br/>';
$html .='<input type="text" name="txtNamaProduk"
placeholder="Masukan Nama Produk " size="30" required/></p>';

$html .='<p>Deskripsi<br/>';
$html .='<input type="text" name="txtDeskripsi"
placeholder="Masukan Deskripsi" size="30" required/>';

$html .='<p>Harga Beli<br/>';
$html .='<input type="text" name="txtHargaBeli"
placeholder="" size="30" required/>';

$html .='<p>Harga Jual<br/>';
$html .='<input type="text" name="txtHargaJual"
placeholder="" size="30" required/>';

$html .='<p><input type="submit" name="tombolSimpan"
value="Simpan"/></p>';
$html .='</form>';
echo $html;
}
// aksi tambah data
else if ($_GET['aksi']=='simpan') {
$data=array(
'id'=>$_POST['txtid'],
'Nama_produk'=>$_POST['txtNamaProduk'],
'Deskripsi'=>$_POST['txtDeskripsi'],
'Harga_Beli'=>$_POST['txtHargaBeli'],
'Harga_Jual'=>$_POST['txtHargaJual'],
);
// simpan Produk dengan menjalankan method simpan
$dataProduk->simpan($data);
echo '<meta http-equiv="refresh" content="0;
url=index.php?file=Produk&aksi=tampil">';
}
// aksi tambah data
else if ($_GET['aksi']=='edit') {
// ambil data Produk
$Produk=$dataProduk->detail($_GET['id']);
if($Produk->deskripsi ) {;
    $pilihP =null; }
    else {
    $pilihP='checked'; $pilihL =null; }
    $html =null;
    $html .='<h3>Form Tambah</h3>';
    $html .='<p>Silahkan masukan form </p>';

    $html .='<form method="POST"
    action="index.php?file=Produk&aksi=update">';

    $html .='<p>ID Produk<br/>';
    $html .='<input type="text" name="txtid"
    value="'.$Produk->id.'" placeholder="Masukan No"
    size="20" required autofocus/></p>';

    $html .='<p>Nama Produk<br/>';
    $html .='<input type="text" name="txtNamaProduk"
    value="'.$Produk->nama_produk.'" placeholder=""
    size="20" required autofocus/></p>';

    $html .='<p>Deskripsi<br/>';
    $html .='<input type="text" name="txtDeskripsi"
    value="'.$Produk->deskripsi.'" placeholder=""
    size="20" required autofocus/></p>';

    $html .='<p>Harga Beli<br/>';
    $html .='<input type="text" name="txtHargaBeli"
    value="'.$Produk->harga_beli.'" placeholder=""
    size="20" required autofocus/></p>';

    $html .='<p>Harga Jual<br/>';
    $html .='<input type="text" name="txtHargaJual"
    value="'.$Produk->harga_jual.'" placeholder=""
    size="20" required autofocus/></p>';
    
    $html .='<p><input type="submit" name="tombolSimpan"
    value="Simpan"/></p>';
    $html .='</form>';
    echo $html;
    }
    // aksi tambah data
    else if ($_GET['aksi']=='update') {
    $data=array(
        'Nama_Produk'=>$_POST['txtNamaProduk'],
        'Deskripsi'=>$_POST['txtDeskripsi'],
        'Harga_Beli'=>$_POST['txtHargaBeli'],
        'Harga_Jual'=>$_POST['txtHargaJual'],
);
$dataProduk->update($_POST['txtid'],$data);
echo '<meta http-equiv="refresh" content="0;
url=index.php?file=Produk&aksi=tampil">';
}
// aksi tambah data
else if ($_GET['aksi']=='hapus') {
$dataProduk->hapus($_GET['id']);
echo '<meta http-equiv="refresh" content="0;
url=index.php?file=Produk&aksi=tampil">';
}
// aksi tidak terdaftar
else {
echo '<p>Error 404 : Halaman tidak ditemukan !</p>';
}
?>