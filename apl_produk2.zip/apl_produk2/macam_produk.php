<?php
// membuat instance
$datamacam_produk=NEW macam_produk;
// aksi tampil data
if($_GET['aksi']=='tampil'){
// aksi untuk tampil data
$html = null;
$html .='<h3>Daftar macam produk</h3>';
$html .='<p>Berikut ini data macam produk </p>';
$html .='<table border="1" width="100%" class="table table-striped table-hover">
<a href="index.php?file=macam_produk&aksi=tambah">Tambah Data macam_produk </a>
<thead>
<tr class="">
<th>No</th>
<th>id produk</th>
<th>Nama produk</th>
<th>jenis produk</th>
<th>Aksi</th>
</tr>
</thead>
<tbody>';
// variabel $data menyimpan hasil return
$data = $datamacam_produk->tampil();
$no=null;
if(isset($data)){
foreach($data as $barismacam_produk)

{
$no++;
$html .='<tr>
<td>'.$no.'</td>
<td>'.$barismacam_produk->id.'</td>
<td>'.$barismacam_produk->nama_produk.'</td>
<td>'.$barismacam_produk->jenis_produk.'</td>
<td>
<a
href="index.php?file=macam_produk&aksi=edit&id='.$barismacam_produk->id.'">Edit</a>
<a
href="index.php?file=macam_produk&aksi=hapus&id='.$barismacam_produk->id.'">Hapus</a>
</td>
</tr>';
}
}
$html .='</tbody>
</table>';
echo $html;
}
// aksi tambah data
else if ($_GET['aksi']=='tambah') {
$html =null;
$html .='<h3>Form Tambah</h3>';

$html .='<p>Silahkan masukan form </p>';

$html .='<form method="POST"
action="index.php?file=macam_produk&aksi=simpan">';

$html .='<p>id produk<br/>';
$html .='<input type="text" name="txtidproduk"
placeholder="Masukan id produk " size="30" required/></p>';

$html .='<p>nama produk<br/>';
$html .='<input type="text" name="txtnamaproduk"
placeholder="Masukan nama produk" size="30" required/>';

$html .='<p>jenis produk<br/>';
$html .='<input type="text" name="txtjenisproduk"
placeholder="Masukan jenis produk" size="30" required/>';

$html .='<p><input type="submit" name="tombolSimpan"
value="Simpan"/></p>';
$html .='</form>';
echo $html;
}
// aksi tambah data
else if ($_GET['aksi']=='simpan') {
$data=array(
'id'=>$_POST['txtidproduk'],
'nama_produk'=>$_POST['txtnamaproduk'],
'jenis_produk'=>$_POST['txtjenisproduk'],
);
// simpan macam_produk dengan menjalankan method simpan
$datamacam_produk->simpan($data);
echo '<meta http-equiv="refresh" content="0;
url=index.php?file=macam_produk&aksi=tampil">';
}
// aksi tambah data
else if ($_GET['aksi']=='edit') {
// ambil data macam_produk
$macam_produk=$datamacam_produk->detail($_GET['id']);
if($macam_produk->nama_produk ) {;
    $pilihP =null; }
    else {
    $pilihP='checked'; $pilihL =null; }
    $html =null;
    $html .='<h3>Form Tambah</h3>';
    $html .='<p>Silahkan masukan form </p>';

    $html .='<form method="POST"
    action="index.php?file=macam_produk&aksi=update">';

    $html .='<p>id produk<br/>';
    $html .='<input type="text" name="txtid"
    value="'.$macam_produk->id.'" placeholder="Masukan Id"
    size="20" required autofocus/></p>';

    $html .='<p>Nama produk<br/>';
    $html .='<input type="text" name="txtnamaproduk"
    value="'.$macam_produk->nama_produk.'" placeholder=""
    size="20" required autofocus/></p>';

    $html .='<p>jenis produk<br/>';
    $html .='<input type="text" name="txtjenisproduk"
    value="'.$macam_produk->jenis_produk.'" placeholder=""
    size="20" required autofocus/></p>';

    $html .='<p><input type="submit" name="tombolSimpan"
    value="Simpan"/></p>';
    $html .='</form>';
    echo $html;
    }
    // aksi tambah data
    else if ($_GET['aksi']=='update') {
    $data=array(
        'nama_produk'=>$_POST['txtnamaproduk'],
        'jenis_produk'=>$_POST['txtjenisproduk'],
);
$datamacam_produk->update($_POST['txtid'],$data);
echo '<meta http-equiv="refresh" content="0;
url=index.php?file=macam_produk&aksi=tampil">';
}
// aksi tambah data
else if ($_GET['aksi']=='hapus') {
$datamacam_produk->hapus($_GET['id']);
echo '<meta http-equiv="refresh" content="0;
url=index.php?file=macam_produk&aksi=tampil">';
}
// aksi tidak terdaftar
else {
echo '<p>Error 404 : Halaman tidak ditemukan !</p>';
}
?>